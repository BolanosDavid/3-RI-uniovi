package uo.ri.cws.application.service.payroll.crud.commands;

import java.time.LocalDate;
import java.util.List;

import uo.ri.cws.application.persistence.util.command.Command;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollDto;

public class GenerateLastMonthPayroll extends GeneratePayrollsAtDate
        implements Command<List<PayrollDto>> {
    public GenerateLastMonthPayroll() {
        super(LocalDate.now());
    }

}
