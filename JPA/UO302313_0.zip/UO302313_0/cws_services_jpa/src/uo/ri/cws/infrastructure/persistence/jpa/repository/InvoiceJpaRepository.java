package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.Optional;

import uo.ri.cws.application.repository.InvoiceRepository;
import uo.ri.cws.domain.Invoice;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class InvoiceJpaRepository
		extends BaseJpaRepository<Invoice>
		implements InvoiceRepository {

	@Override
	public Optional<Invoice> findByNumber(Long number) {
	    String query = "Invoice.findByNumber";
		return Jpa.getManager() 
				.createNamedQuery(query,Invoice.class)
				.setParameter(1, number)
				.getResultStream()
				.findFirst();
	}

	@Override
	public Long getNextInvoiceNumber() {
	    String query = "Invoice.getNextInvoiceNumber";
		return Jpa.getManager()
				.createNamedQuery(query,Long.class)
				.getSingleResult();
				
	}

}
