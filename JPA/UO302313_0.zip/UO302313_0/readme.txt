Nombre: David Fernando Bolaños López
UO: UO302313
Casos de uso: 
	MODULO0: 
	– Gestión de nóminas
	– Gestión de tipos de contrato
	– Gestión de mecánicos ampliado
Ampliaciones:
	-Mapeo externo de clases: 
		+orm-with-mapping.xml
	-Hacer clientes en modo GUI (cws_client_manager):
		+Modulo  -> cws_client_manager_gui
Comentarios:
	+Respecto a los tests de  búsqueda de nóminas, 
	Los tests utilizan el método:
	dtoMatchesRecord(TPayrollsRecord expected, PayrollDto found) 
	y concretamente:
	assertEquals(totalizer.netSalary(), found.netSalary, 0.001);
	
	El aserto no cuadra con lo mencionado en el pdf donde se menciona
	que el netSalary debería aproximarse al segundo decimal lo cual
	hace que algunos tests me fallen por la aproximación. 